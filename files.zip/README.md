# User Profile Card Generator 🪪

A form-based web application where users input their details and get a beautifully formatted profile card. Built with Python Flask backend and HTML/CSS/JS frontend.

## Tech Stack
- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Python Flask
- **Data Format**: JSON (POST request)

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Open in browser
Go to: http://localhost:5000

## Features
- ✅ Input form: Name, Role, Bio, Photo URL
- ✅ POST request sent to Flask backend
- ✅ Backend validates and processes data
- ✅ Returns formatted profile card on frontend
- ✅ Auto-generated avatar if no photo URL provided
- ✅ Responsive design

## API Endpoint
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /generate | Submit profile data, returns profile card JSON |

## Project Structure
```
profilecard/
├── app.py          # Flask backend
├── index.html      # Frontend UI
├── requirements.txt
└── README.md
```
