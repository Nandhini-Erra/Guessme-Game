from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

app = Flask(__name__, static_folder='.')
CORS(app)

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/generate', methods=['POST'])
def generate_profile():
    data = request.get_json()

    name = data.get('name', '').strip()
    bio = data.get('bio', '').strip()
    image_url = data.get('image_url', '').strip()
    role = data.get('role', '').strip()

    if not name:
        return jsonify({'error': 'Name is required'}), 400

    # Default avatar if no image provided
    if not image_url:
        initials = ''.join([word[0].upper() for word in name.split()[:2]])
        image_url = f"https://ui-avatars.com/api/?name={name}&background=f5c842&color=0f0f13&size=200&bold=true"

    profile_data = {
        'name': name,
        'bio': bio if bio else 'No bio provided.',
        'image_url': image_url,
        'role': role if role else 'Member'
    }

    return jsonify(profile_data), 200

if __name__ == '__main__':
    print("✅ Profile Card Generator running at http://localhost:5000")
    app.run(debug=True, port=5000)
